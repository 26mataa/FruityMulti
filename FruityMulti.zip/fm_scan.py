"""Inventaire des plugins disponibles sur cette machine.

Produit un fichier JSON comparable a celui de l'autre poste :

    {
      "poste": "NOM-DU-PC",
      "date": "2026-10-28T17:20:00",
      "fl":   ["Fruity Keyboard Controller", "FPC", ...],
      "vst3": ["Serum", "Vital", ...],
      "vst2": ["Massive", ...]
    }

Aucune installation, aucune modification : on ne fait que lire des noms de
fichiers. Usage :

    python fm_scan.py                     -> inventaire_<poste>.json
    python fm_scan.py --sortie mon.json
"""

import argparse
import datetime
import json
import os
import socket
import sys


# Dossiers ou chercher les VST3. FL utilise les emplacements standard de
# Windows ; on les couvre tous les deux (64 et 32 bits).
DOSSIERS_VST3 = [
    r"C:\Program Files\Common Files\VST3",
    r"C:\Program Files (x86)\Common Files\VST3",
]

# Dossiers ou chercher les VST2 (.dll). La liste est volontairement courte :
# les chemins personnalises se declarant dans FL, pas ici.
DOSSIERS_VST2 = [
    r"C:\Program Files\VstPlugins",
    r"C:\Program Files\Steinberg\VSTPlugins",
    r"C:\Program Files\Common Files\VST2",
    r"C:\VST",
    r"C:\VSTPlugins",
]


def dossiers_fl():
    """Emplacements possibles de la base de plugins de FL Studio."""
    doc = os.path.expanduser("~\\Documents")
    candidats = [
        os.path.join(doc, "Image-Line", "FL Studio", "Presets",
                     "Plugin database"),
        os.path.join(doc, "Image-Line", "FL Studio 21", "Presets",
                     "Plugin database"),
        os.path.join(doc, "Image-Line", "FL Studio 20", "Presets",
                     "Plugin database"),
    ]
    return [c for c in candidats if os.path.isdir(c)]


def scan_fl():
    """Generateurs integres a FL : un .fst par plugin, range par categorie."""
    noms = set()
    for base in dossiers_fl():
        generateurs = os.path.join(base, "Generators")
        if not os.path.isdir(generateurs):
            continue
        for racine, _dossiers, fichiers in os.walk(generateurs):
            for fichier in fichiers:
                if fichier.lower().endswith(".fst"):
                    noms.add(os.path.splitext(fichier)[0])
    return sorted(noms, key=str.lower)


def scan_vst3():
    """Bundles .vst3 : un fichier, ou un dossier se terminant par .vst3."""
    noms = set()
    for dossier in DOSSIERS_VST3:
        if not os.path.isdir(dossier):
            continue
        for entree in os.listdir(dossier):
            chemin = os.path.join(dossier, entree)
            if entree.lower().endswith(".vst3"):
                noms.add(os.path.splitext(entree)[0])
            elif os.path.isdir(chemin):
                # dossier de fabricant : on descend d'un niveau
                for sous in os.listdir(chemin):
                    if sous.lower().endswith(".vst3"):
                        noms.add(os.path.splitext(sous)[0])
    return sorted(noms, key=str.lower)


def scan_vst2():
    """DLL de plugins VST2."""
    noms = set()
    for dossier in DOSSIERS_VST2:
        if not os.path.isdir(dossier):
            continue
        for racine, _dossiers, fichiers in os.walk(dossier):
            for fichier in fichiers:
                if fichier.lower().endswith(".dll"):
                    noms.add(os.path.splitext(fichier)[0])
            # on ne descend pas trop profond : les DLL de support ne sont pas
            # des plugins et pollueraient la liste
            if racine.count(os.sep) - dossier.count(os.sep) >= 2:
                _dossiers[:] = []
    return sorted(noms, key=str.lower)


def inventaire():
    return {
        "poste": socket.gethostname().upper(),
        "date": datetime.datetime.now().isoformat(timespec="seconds"),
        "fl": scan_fl(),
        "vst3": scan_vst3(),
        "vst2": scan_vst2(),
    }


def main():
    parser = argparse.ArgumentParser(
        description="Inventaire des plugins de ce poste")
    parser.add_argument("--sortie", help="fichier JSON a ecrire")
    args = parser.parse_args()

    donnees = inventaire()
    sortie = args.sortie or f"inventaire_{donnees['poste']}.json"
    with open(sortie, "w", encoding="utf-8") as fichier:
        json.dump(donnees, fichier, ensure_ascii=False, indent=2)

    total = len(donnees["fl"]) + len(donnees["vst3"]) + len(donnees["vst2"])
    print(f"poste       : {donnees['poste']}")
    for base in dossiers_fl():
        print(f"base FL     : {base}")
    print(f"generateurs : {len(donnees['fl'])}")
    print(f"VST3        : {len(donnees['vst3'])}")
    print(f"VST2        : {len(donnees['vst2'])}")
    print(f"total       : {total}")
    print(f"ecrit       : {sortie}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
