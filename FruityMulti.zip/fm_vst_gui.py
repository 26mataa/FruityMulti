"""Comparaison des plugins entre les deux postes.

Usage :
    python fm_vst_gui.py

1. "Scanner ce poste"          -> inventaire local
2. "Ouvrir l'inventaire de l'autre" -> le JSON que le pair a envoye

La liste montre, pour chaque plugin, s'il est present :
    - des deux cotes      (vert)
    - seulement ici       (orange)
    - seulement chez lui  (rouge)

Aucune installation, aucune modification : uniquement de la lecture.
"""

import json
import os
import sys
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fm_scan


# ---------------------------------------------------------------------------
# Logique de comparaison (testable sans interface)
# ---------------------------------------------------------------------------

CATEGORIES = (("fl", "Generateurs FL"), ("vst3", "VST3"), ("vst2", "VST2"))


def comparer(ici, autre):
    """Renvoie {categorie: [(nom, etat)]} avec etat = 'deux', 'ici', 'autre'.

    La comparaison ignore la casse : deux postes peuvent ecrire un nom avec
    une majuscule differente.
    """
    resultat = {}
    for cle, _libelle in CATEGORIES:
        miens = {nom.lower(): nom for nom in (ici or {}).get(cle, [])}
        siens = {nom.lower(): nom for nom in (autre or {}).get(cle, [])}
        lignes = []
        for minuscule in sorted(set(miens) | set(siens)):
            if minuscule in miens and minuscule in siens:
                lignes.append((miens[minuscule], "deux"))
            elif minuscule in miens:
                lignes.append((miens[minuscule], "ici"))
            else:
                lignes.append((siens[minuscule], "autre"))
        resultat[cle] = lignes
    return resultat


def resume(ici, autre):
    """Comptes par categorie et par etat, pour l'en-tete de l'interface."""
    comparaison = comparer(ici, autre)
    total = {"deux": 0, "ici": 0, "autre": 0}
    for _cle, lignes in comparaison.items():
        for _nom, etat in lignes:
            total[etat] += 1
    return total


# ---------------------------------------------------------------------------
# Interface
# ---------------------------------------------------------------------------

COULEURS = {"deux": "#1b5e20", "ici": "#e65100", "autre": "#b71c1c"}
FONDS = {"deux": "#e8f5e9", "ici": "#fff3e0", "autre": "#ffebee"}


class Fenetre(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("FruityMulti - plugins en commun")
        self.geometry("820x620")
        self.minsize(680, 460)

        self.ici = None
        self.autre = None
        self.filtre = tk.StringVar()

        self._construire()
        self._rafraichir()

    # -- construction ------------------------------------------------------
    def _construire(self):
        haut = ttk.Frame(self, padding=8)
        haut.pack(fill="x")

        ttk.Button(haut, text="Scanner ce poste",
                   command=self._scanner).pack(side="left")
        ttk.Button(haut, text="Ouvrir l'inventaire de l'autre",
                   command=self._charger).pack(side="left", padx=6)
        ttk.Button(haut, text="Tout exporter",
                   command=self._exporter).pack(side="left")

        self.etat = ttk.Label(self, padding=(8, 0))
        self.etat.pack(fill="x")

        filtre = ttk.Frame(self, padding=(8, 6))
        filtre.pack(fill="x")
        ttk.Label(filtre, text="Chercher :").pack(side="left")
        entree = ttk.Entry(filtre, textvariable=self.filtre)
        entree.pack(side="left", fill="x", expand=True, padx=6)
        self.filtre.trace_add("write", lambda *_: self._remplir())

        cadre = ttk.Frame(self, padding=8)
        cadre.pack(fill="both", expand=True)

        self.liste = ttk.Treeview(cadre, columns=("etat",), show="tree headings")
        self.liste.heading("#0", text="Plugin")
        self.liste.heading("etat", text="Disponibilite")
        self.liste.column("#0", width=430)
        self.liste.column("etat", width=170)
        self.liste.tag_configure("deux", foreground=COULEURS["deux"],
                                 background=FONDS["deux"])
        self.liste.tag_configure("ici", foreground=COULEURS["ici"],
                                 background=FONDS["ici"])
        self.liste.tag_configure("autre", foreground=COULEURS["autre"],
                                 background=FONDS["autre"])

        barre = ttk.Scrollbar(cadre, orient="vertical",
                              command=self.liste.yview)
        self.liste.configure(yscrollcommand=barre.set)
        self.liste.pack(side="left", fill="both", expand=True)
        barre.pack(side="right", fill="y")

    # -- actions -----------------------------------------------------------
    def _scanner(self):
        self.ici = fm_scan.inventaire()
        self._rafraichir()

    def _charger(self):
        chemin = filedialog.askopenfilename(
            title="Inventaire de l'autre poste",
            filetypes=[("Inventaire JSON", "*.json"), ("Tous", "*.*")])
        if not chemin:
            return
        try:
            with open(chemin, "r", encoding="utf-8") as fichier:
                self.autre = json.load(fichier)
        except (OSError, ValueError) as erreur:
            messagebox.showerror("Lecture impossible", str(erreur))
            return
        self._rafraichir()

    def _exporter(self):
        if self.ici is None:
            messagebox.showinfo("Rien a exporter", "Scanne d'abord ce poste.")
            return
        chemin = filedialog.asksaveasfilename(
            defaultextension=".json",
            initialfile=f"inventaire_{self.ici['poste']}.json",
            filetypes=[("Inventaire JSON", "*.json")])
        if not chemin:
            return
        with open(chemin, "w", encoding="utf-8") as fichier:
            json.dump(self.ici, fichier, ensure_ascii=False, indent=2)
        messagebox.showinfo("Exporte", f"Inventaire ecrit dans\n{chemin}")

    # -- affichage ---------------------------------------------------------
    def _rafraichir(self):
        if self.ici is None:
            self.etat.config(text="Scanne ce poste pour commencer.")
        elif self.autre is None:
            self.etat.config(
                text=f"{self.ici['poste']} : "
                     f"{len(self.ici['fl'])} generateurs FL, "
                     f"{len(self.ici['vst3'])} VST3, "
                     f"{len(self.ici['vst2'])} VST2.  "
                     f"Ouvre maintenant l'inventaire de l'autre.")
        else:
            compte = resume(self.ici, self.autre)
            self.etat.config(
                text=f"{self.ici['poste']} contre {self.autre['poste']} : "
                     f"{compte['deux']} en commun, "
                     f"{compte['ici']} seulement ici, "
                     f"{compte['autre']} seulement chez lui.")
        self._remplir()

    def _remplir(self):
        self.liste.delete(*self.liste.get_children())
        if self.ici is None:
            return

        texte = self.filtre.get().strip().lower()
        source = comparer(self.ici, self.autre) if self.autre else None

        for cle, libelle in CATEGORIES:
            if source is None:
                lignes = [(nom, "ici") for nom in self.ici.get(cle, [])]
            else:
                lignes = source[cle]
            if texte:
                lignes = [l for l in lignes if texte in l[0].lower()]
            if not lignes:
                continue

            deux = sum(1 for _n, e in lignes if e == "deux")
            titre = f"{libelle} ({len(lignes)}"
            if source is not None:
                titre += f", {deux} en commun"
            titre += ")"

            parent = self.liste.insert("", "end", text=titre, open=len(lignes) < 40)
            for nom, etat in lignes:
                etiquette = {"deux": "les deux cotes",
                             "ici": "seulement ici",
                             "autre": "seulement chez lui"}[etat]
                self.liste.insert(parent, "end", text="   " + nom,
                                  values=(etiquette,), tags=(etat,))


def main():
    app = Fenetre()
    app.mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
