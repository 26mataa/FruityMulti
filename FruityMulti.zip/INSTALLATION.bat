@echo off
chcp 65001 >nul
title FruityMulti - installation
echo ==========================================
echo   FruityMulti - installation
echo ==========================================
echo.
echo Ce script copie le plugin et l'agent aux bons endroits,
echo et affiche exactement ce qu'il fait.
echo.

rem --- droits d'administrateur (necessaires pour Program Files)
net session >nul 2>&1
if errorlevel 1 (
  echo Demande des droits d'administrateur...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)

rem --- FL doit etre ferme
tasklist /FI "IMAGENAME eq FL64.exe" 2>nul | find /I "FL64.exe" >nul
if not errorlevel 1 (
  echo.
  echo   *** FL Studio est ouvert. ***
  echo.
  echo   Ferme-le completement, puis relance ce script.
  echo   Remplacer le plugin pendant que FL tourne le fait planter.
  echo.
  pause
  exit /b 1
)

set "SRC=%~dp0"
set "VST3=%CommonProgramFiles%\VST3"
set "AGENT=%LOCALAPPDATA%\FruityMulti"

echo 1. Plugin
rem FL Studio scanne les deux dossiers : on ecrit dans les deux.
for %%D in ("%CommonProgramFiles%\VST3" "%CommonProgramFiles(x86)%\VST3") do (
  if not exist "%%~D" mkdir "%%~D"
  copy /Y "%SRC%FruityMultiBridge.vst3" "%%~D\FruityMultiBridge.vst3" >nul
  if errorlevel 1 (
    echo    ECHEC : %%\~D
  ) else (
    echo    OK : %%~D\FruityMultiBridge.vst3
  )
)
echo.

echo 2. Agent vers %AGENT%
if not exist "%AGENT%" mkdir "%AGENT%"
copy /Y "%SRC%fm_agent.exe" "%AGENT%\fm_agent.exe" >nul
if errorlevel 1 (
  echo    ECHEC : impossible d'ecrire dans %AGENT%
) else (
  echo    OK : %AGENT%\fm_agent.exe
)
echo.

if exist "%SRC%FruityMultiSetup.exe" (
  echo 3. Installateur conserve pour les mises a jour
  copy /Y "%SRC%FruityMultiSetup.exe" "%AGENT%\FruityMultiSetup.exe" >nul
  echo    OK : %AGENT%\FruityMultiSetup.exe
  echo.
)

echo ==========================================
echo   Termine.
echo ==========================================
echo.
echo Relance FL Studio, puis ajoute l'effet
echo "FruityMulti Bridge" sur une piste du mixeur.
echo.
pause
